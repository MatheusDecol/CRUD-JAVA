package com.example.pessoa_trabalho.services;

import com.example.pessoa_trabalho.dto.PessoaCreateDTO;
import com.example.pessoa_trabalho.dto.PessoaDTO;
import com.example.pessoa_trabalho.model.Pessoa;
import com.example.pessoa_trabalho.model.Trabalho;
import com.example.pessoa_trabalho.repository.PessoaRepository;
import com.example.pessoa_trabalho.repository.TrabalhoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.stream.Collectors;

@Service
public class PessoaService {
    @Autowired
    private PessoaRepository pessoaRepo;

    @Autowired
    private TrabalhoRepository trabalhoRepo;

    public PessoaDTO create(PessoaCreateDTO dto) {
        Trabalho trabalho = trabalhoRepo.findById(dto.getTrabalhoId()).orElseThrow();
        Pessoa pessoa = new Pessoa(dto.getNome(), dto.getCpf(), trabalho);
        pessoa = pessoaRepo.save(pessoa);
        return toDTO(pessoa);
    }

    public List<PessoaDTO> listar() {
        return pessoaRepo.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public PessoaDTO buscar(Long id) {
        return pessoaRepo.findById(id).map(this::toDTO).orElse(null);
    }

    public void deletar(Long id) {
        pessoaRepo.deleteById(id);
    }

    public PessoaDTO update(Long id, PessoaCreateDTO dto) {
        Pessoa pessoa = pessoaRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Pessoa não encontrada com id: " + id));

        Trabalho trabalho = trabalhoRepo.findById(dto.getTrabalhoId())
                .orElseThrow(() -> new RuntimeException("Trabalho não encontrado com id: " + dto.getTrabalhoId()));

        pessoa.setNome(dto.getNome());
        pessoa.setCpf(dto.getCpf());
        pessoa.setTrabalho(trabalho);

        pessoa = pessoaRepo.save(pessoa);

        return toDTO(pessoa);
    }


    private PessoaDTO toDTO(Pessoa p) {
        return new PessoaDTO(p.getId(), p.getNome(), p.getCpf(), p.getTrabalho().getEndereco());
    }
}
