package com.example.pessoa_trabalho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PessoaTrabalhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PessoaTrabalhoApplication.class, args);
	}

}
