package com.example.pessoa_trabalho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaTrabalhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
